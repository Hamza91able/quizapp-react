import React, { Component } from 'react';
import Register from '../Register/Register';
import firebase from '../../fire';
import swal from 'sweetalert'

class Navbar extends Component {
    constructor() {
        super();
        this.state = {
            showRegister: false,
            showLogin: false,
        }
        this.showRegister = this.showRegister.bind(this);
        this.showLogin = this.showLogin.bind(this);
        this.logOut = this.logOut.bind(this);
    }

    showLogin() {
        console.log("Show Login");
        this.props.showLogin();
    }


    showRegister() {
        console.log("Show Register");
        this.props.changeLoggedInState();
    }

    logOut() {
        firebase.auth().signOut().then(() => {
            this.props.logOut();
            swal("Logged Out Successfully");
        }).catch(function (error) {
            swal("An Error Occured: " + error);
        });
    }

    renderNavBar() {
        return (
            <nav className="navbar navbar-inverse">
                <div className="container-fluid">
                    <div className="navbar-header">
                        <a className="navbar-brand">Quiz Application</a>
                    </div>
                    <ul className="nav navbar-nav navbar-right">
                        {!this.props.isLoggedIn && <li><a onClick={this.showRegister}><span className="glyphicon glyphicon-user"></span> Sign Up</a></li>}
                        {!this.props.isLoggedIn && <li><a onClick={this.showLogin}><span className="glyphicon glyphicon-log-in"></span> Login</a></li>}
                    </ul>
                    {this.props.isLoggedIn && <ul className="nav navbar-nav navbar-right">
                        <li><a><span className="glyphicon glyphicon-user"></span> Welcome: {firebase.auth().currentUser.email}</a></li>
                        <li><a onClick={this.logOut}><span className="glyphicon glyphicon-log-out"></span> Logout</a></li>
                    </ul>}
                </div>
            </nav>
        )
    }

    render() {
        return (
            <div>
                {this.renderNavBar()}
                {this.state.showRegister && <Register />}
            </div>
        )
    }
}

export default Navbar;